\include "lilypond-book-preamble.ly"

\header{
  tagline=""
}

\score {
  { 
    \override Staff.TimeSignature.stencil = ##f
    \override Staff.Stem.stencil = ##f
    \time 7/4
    c' d' ees' f' g' aes' bes'
  }
  \layout {
    \context {
      \Score
      \override SpacingSpanner.base-shortest-duration = #(ly:make-moment 1/16)
    }
  }
}